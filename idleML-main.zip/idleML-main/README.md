run order

1. prepare_dataset.py
2. train_model.py
3. grid_search.py
