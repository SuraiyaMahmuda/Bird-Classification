import joblib
import numpy as np
import os
from collections import Counter
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import SGDClassifier
from sklearn.pipeline import Pipeline
from sklearn.metrics import confusion_matrix
from mpl_toolkits.axes_grid1 import make_axes_locatable

# Import custom transformers.
from transformers import RGB2GrayTransformer, HogTransformer

def load_dataset(pkl_filename):
    data = joblib.load(pkl_filename)
    return data

def plot_samples(data):
    """
    Plot one sample image per label.
    """
    labels = np.unique(data['label'])
    fig, axes = plt.subplots(1, len(labels), figsize=(15, 4))
    fig.tight_layout()
    for ax, label in zip(axes, labels):
        idx = data['label'].index(label)
        ax.imshow(data['data'][idx])
        ax.set_title(label)
        ax.axis('off')
    plt.show()

def plot_confusion_matrix(cmx, vmax1=None, vmax2=None, vmax3=None):
    """
    Plot the confusion matrix in three different ways.
    """
    cmx_norm = 100 * cmx / cmx.sum(axis=1, keepdims=True)
    cmx_zero_diag = cmx_norm.copy()
    np.fill_diagonal(cmx_zero_diag, 0)

    fig, axes = plt.subplots(ncols=3, figsize=(12, 3))
    for ax in axes:
        ax.set_xticks(range(cmx.shape[0] + 1))
        ax.set_yticks(range(cmx.shape[0] + 1))

    im1 = axes[0].imshow(cmx, vmax=vmax1)
    axes[0].set_title('As is')
    im2 = axes[1].imshow(cmx_norm, vmax=vmax2)
    axes[1].set_title('%')
    im3 = axes[2].imshow(cmx_zero_diag, vmax=vmax3)
    axes[2].set_title('% (0 diag)')

    # Create colorbars.
    for ax in axes:
        divider = make_axes_locatable(ax)
        cax = divider.append_axes("right", size="5%", pad=0.1)
        plt.colorbar(im1, cax=cax)
    plt.tight_layout()
    plt.show()

def main():
    pkl_filename = os.path.join(os.getcwd(), 'animal_faces_80x80px.pkl')
    data = load_dataset(pkl_filename)
    
    print("Number of samples:", len(data['data']))
    print("Image shape:", data['data'][0].shape)
    print("Unique labels:", np.unique(data['label']))
    print("Label distribution:", Counter(data['label']))
    
    # Plot one sample per label.
    plot_samples(data)
    
    # Prepare the arrays.
    X = np.array(data['data'])
    y = np.array(data['label'])
    
    # Split data into training and testing sets.
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, shuffle=True, random_state=42)
    
    # Create the pipeline.
    pipeline = Pipeline([
        ('grayify', RGB2GrayTransformer()),
        ('hogify', HogTransformer(
            pixels_per_cell=(14, 14),
            cells_per_block=(2, 2),
            orientations=9,
            block_norm='L2-Hys'
        )),
        ('scalify', StandardScaler()),
        ('classify', SGDClassifier(random_state=42, max_iter=1000, tol=1e-3))
    ])
    
    # Train the classifier.
    clf = pipeline.fit(X_train, y_train)
    test_accuracy = 100 * np.sum(clf.predict(X_test) == y_test) / len(y_test)
    print("Test accuracy: {:.2f}%".format(test_accuracy))
    
    # Compute and display the confusion matrix.
    y_pred = clf.predict(X_test)
    cmx = confusion_matrix(y_test, y_pred)
    print("Confusion matrix:")
    print(cmx)
    plot_confusion_matrix(cmx)
    joblib.dump(clf, "trained_model.pkl")
if __name__ == '__main__':
    main()
