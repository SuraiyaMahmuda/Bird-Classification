import joblib
import numpy as np
from sklearn.pipeline import Pipeline
from sklearn.linear_model import SGDClassifier
from sklearn.model_selection import GridSearchCV, train_test_split
from sklearn.preprocessing import StandardScaler
# Import the custom transformers.
from transformers import RGB2GrayTransformer, HogTransformer

def main():
    pkl_filename = 'animal_faces_80x80px.pkl'
    data = joblib.load(pkl_filename)
    X = np.array(data['data'])
    y = np.array(data['label'])
    
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, shuffle=True, random_state=42)
    
    pipeline = Pipeline([
        ('grayify', RGB2GrayTransformer()),
        ('hogify', HogTransformer(
            pixels_per_cell=(14, 14),
            cells_per_block=(2, 2),
            orientations=9,
            block_norm='L2-Hys'
        )),
        ('scalify', StandardScaler()),
        ('classify', SGDClassifier(random_state=42, max_iter=1000, tol=1e-3))
    ])
    
    # Define the parameter grid. The first dictionary explores different HOG parameters.
    # In the second dictionary you can experiment with a different classifier setup.
    param_grid = [
        {
            'hogify__orientations': [8, 9],
            'hogify__cells_per_block': [(2, 2), (3, 3)],
            'hogify__pixels_per_cell': [(8, 8), (10, 10), (12, 12)]
        },
        {
            'hogify__orientations': [8],
            'hogify__cells_per_block': [(3, 3)],
            'hogify__pixels_per_cell': [(8, 8), (10, 10), (12, 12)],
            # Uncomment and add another classifier (e.g., SVM) if desired.
            # 'classify': [SGDClassifier(random_state=42, max_iter=1000, tol=1e-3),
            #              SVC(random_state=42)]
        }
    ]
    
    grid = GridSearchCV(pipeline, param_grid, cv=3, scoring='accuracy', n_jobs=-1)
    grid_res = grid.fit(X_train, y_train)
    
    print("Best parameters:")
    print(grid.best_params_)
    joblib.dump(grid_res, 'hog_sgd_model.pkl')
    test_score = grid.score(X_test, y_test)
    print("Test set accuracy: {:.2f}%".format(100 * test_score))

if __name__ == '__main__':
    main()
