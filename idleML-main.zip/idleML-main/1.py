import os

# Path to the parent directory containing the folders
parent_directory = "Train"

# Loop through all items in the directory
for folder_name in os.listdir(parent_directory):
    folder_path = os.path.join(parent_directory, folder_name)

    # Check if it's a folder
    if os.path.isdir(folder_path):
        # Replace () and - with _
        new_name = folder_name.replace("(", "_").replace(")", "_").replace("-", "_")

        # Create full new path
        new_path = os.path.join(parent_directory, new_name)

        # Rename the folder
        os.rename(folder_path, new_path)
        print(f"Renamed: {folder_name} -> {new_name}")
