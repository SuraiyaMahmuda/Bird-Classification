import joblib
import numpy as np
import matplotlib.pyplot as plt
from skimage.io import imread
from skimage.transform import resize

# Load the trained pipeline from disk
# Make sure the path matches where you saved your pipeline.
clf = joblib.load("hog_sgd_model.pkl")

# Define the target dimensions that were used during training.
TARGET_WIDTH = 80
TARGET_HEIGHT = 80

def load_and_preprocess_image(image_path):
    """
    Loads an image from the provided path, resizes it to the target dimensions,
    and returns it in an array ready for prediction.
    """
    # Load the image (it can be in color)
    img = imread(image_path)
    
    # Resize the image to the dimensions used for training.
    img_resized = resize(img, (TARGET_WIDTH, TARGET_HEIGHT))
    
    # Return the image as a single-element batch.
    return np.array([img_resized])

# Set the path for your unknown image.
image_path = "Asian_koel-1.jpg"  # <-- Change to the correct image file path

# Preprocess the image.
X_new = load_and_preprocess_image(image_path)

# Use the pipeline to predict the label.
prediction = clf.predict(X_new)

print("Predicted label:", prediction[0])

# Optionally, display the image with its predicted label.
plt.imshow(X_new[0])
plt.title("Predicted label: " + prediction[0])
plt.axis("off")
plt.show()
