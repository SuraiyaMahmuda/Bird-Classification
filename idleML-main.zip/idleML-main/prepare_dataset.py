import os
import joblib
from skimage.io import imread
from skimage.transform import resize

def resize_all(src, pklname, include, width=150, height=None):
    """
    Load images from a given path, resize them and save them to a pickle file.
    
    Parameters
    ----------
    src : str
        Path to the folder containing subdirectories (each one for a category).
    pklname : str
        Base name for the output pickle file.
    include : set[str]
        Set of subdirectory names to be included.
    width : int
        Target width (in pixels).
    height : int or None
        Target height (in pixels). If None, height is set equal to width.
    """
    height = height if height is not None else width
    data = {
        'description': f"resized ({width}x{height}) animal images in rgb",
        'label': [],
        'filename': [],
        'data': []
    }
    pkl_filename = f"{pklname}_{width}x{height}px.pkl"

    # Process each subfolder (category) in the source directory.
    for subdir in os.listdir(src):
        if subdir in include:
            print(f"Processing {subdir}")
            current_path = os.path.join(src, subdir)
            for file in os.listdir(current_path):
                if file.lower().endswith(('jpg', 'png')):
                    img_path = os.path.join(current_path, file)
                    im = imread(img_path)
                    im = resize(im, (width, height))
                    # Create a label; here we remove the 'Head' suffix.
                    label = subdir.replace("Head", "")
                    data['label'].append(label)
                    data['filename'].append(file)
                    data['data'].append(im)
    # Save the data to a pickle file.
    joblib.dump(data, pkl_filename)
    print(f"Data saved to {pkl_filename}")

if __name__ == "__main__":
    # Modify to fit your system: path to unzipped data folder.
    data_path = "Image"
    base_name = 'animal_faces'
    width = 80
    # Only include a selection of the available classes.
    include = {'ChickenHead', 'BearHead', 'ElephantHead', 
               'EagleHead', 'DeerHead', 'MonkeyHead', 'PandaHead'}
    
    resize_all(src=data_path, pklname=base_name, width=width, include=include)
