import numpy as np
from skimage import color
from skimage.feature import hog
from sklearn.base import BaseEstimator, TransformerMixin

class RGB2GrayTransformer(BaseEstimator, TransformerMixin):
    """
    Convert an array of RGB images to grayscale.
    """
    def fit(self, X, y=None):
        return self

    def transform(self, X, y=None):
        return np.array([color.rgb2gray(img) for img in X])

class HogTransformer(BaseEstimator, TransformerMixin):
    """
    Expects an array of 2D arrays (grayscale images) and calculates HOG features.
    """
    def __init__(self, orientations=9, pixels_per_cell=(8,8),
                 cells_per_block=(3,3), block_norm='L2-Hys'):
        self.orientations = orientations
        self.pixels_per_cell = pixels_per_cell
        self.cells_per_block = cells_per_block
        self.block_norm = block_norm

    def fit(self, X, y=None):
        return self

    def transform(self, X, y=None):
        def local_hog(img):
            return hog(
                img,
                orientations=self.orientations,
                pixels_per_cell=self.pixels_per_cell,
                cells_per_block=self.cells_per_block,
                block_norm=self.block_norm
            )
        return np.array([local_hog(img) for img in X])
